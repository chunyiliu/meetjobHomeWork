from django.db import models

# Create your models here.

class Product(models.Model):
    title=models.CharField(max_length=100)
    link=models.CharField(max_length=255)
    photo=models.CharField(max_length=255)
    price=models.IntegerField()
    create_date=models.DateField(auto_now_add=True)
    
    class Meta:
        db_table="shop"