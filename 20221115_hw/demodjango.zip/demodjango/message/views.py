from django.shortcuts import render

# Create your views here.

from .models import Contact
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
from email.mime.image import MIMEImage
from pathlib import Path
import os

def Msg(request):
    
    if 'msgName' in request.POST:
        msgName=request.POST['msgName']
        msgEmail=request.POST['msgEmail']
        msgPhone=request.POST['msgPhone']
        msgMessage=request.POST['msgMessage']
        
        obj=Contact.objects.create(name=msgName,email=msgEmail,phone=msgPhone,content=msgMessage)
        obj.save()
        
        sendMail(msgEmail)

    data=Contact.objects.all().order_by('-create_date')
        
    return render(request,'message.html',locals())


def sendMail(email):
    #建立MIMEMultipart物件
    content = MIMEMultipart()
    
    #郵件標題
    content["subject"] = "NewMessage"
    #寄件者
    content["from"] = email
    #收件者
    content["to"] = "jyliu77@gmail.com"
    #郵件內容
    content.attach(MIMEText("你有新留言"))
    
    #郵件圖片內容
    img_dir = 'static/images/'
    image = 'YOONA.jpg'
    file_path = os.path.join(img_dir, image)
    content.attach(MIMEImage(Path(file_path).read_bytes()))
    with smtplib.SMTP(host="smtp.gmail.com", port="587") as smtp:  # 設定SMTP伺服器
        try:
            smtp.ehlo()  # 驗證SMTP伺服器
            smtp.starttls()  # 建立加密傳輸
            smtp.login("jyliu77@gmail.com", "qijbuqyxhgyknapx")  # 登入寄件者gmail
            smtp.send_message(content)  # 寄送郵件
            print("Complete!")
        except Exception as e:
            print("Error message: ", e) 