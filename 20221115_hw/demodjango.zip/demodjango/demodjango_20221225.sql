-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: demodjango
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add cpbl',7,'add_cpbl'),(26,'Can change cpbl',7,'change_cpbl'),(27,'Can delete cpbl',7,'delete_cpbl'),(28,'Can view cpbl',7,'view_cpbl'),(29,'Can add contact',8,'add_contact'),(30,'Can change contact',8,'change_contact'),(31,'Can delete contact',8,'delete_contact'),(32,'Can view contact',8,'view_contact'),(33,'Can add product',9,'add_product'),(34,'Can change product',9,'change_product'),(35,'Can delete product',9,'delete_product'),(36,'Can view product',9,'view_product'),(37,'Can add orders model',10,'add_ordersmodel'),(38,'Can change orders model',10,'change_ordersmodel'),(39,'Can delete orders model',10,'delete_ordersmodel'),(40,'Can view orders model',10,'view_ordersmodel'),(41,'Can add detail model',11,'add_detailmodel'),(42,'Can change detail model',11,'change_detailmodel'),(43,'Can delete detail model',11,'delete_detailmodel'),(44,'Can view detail model',11,'view_detailmodel'),(45,'Can add person',12,'add_person'),(46,'Can change person',12,'change_person'),(47,'Can delete person',12,'delete_person'),(48,'Can view person',12,'view_person'),(49,'Can add document',13,'add_document'),(50,'Can change document',13,'change_document'),(51,'Can delete document',13,'delete_document'),(52,'Can view document',13,'view_document');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$390000$v3GHh6SdRZRvb7IOZ3NvIl$PdqmNf2YLEM8vKJcP/+T+RKNh3gVFLMyjS5wcQigUOw=','2022-12-06 15:31:54.480980',1,'liu','','','jyliu77@gmail.com',1,1,'2022-11-16 02:25:46.164901');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_detailmodel`
--

DROP TABLE IF EXISTS `cart_detailmodel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_detailmodel` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `pname` varchar(100) NOT NULL,
  `unitprice` int NOT NULL,
  `quantity` int NOT NULL,
  `dtotal` int NOT NULL,
  `dorder_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_detailmodel_dorder_id_4a34f87f_fk_cart_ordersmodel_id` (`dorder_id`),
  CONSTRAINT `cart_detailmodel_dorder_id_4a34f87f_fk_cart_ordersmodel_id` FOREIGN KEY (`dorder_id`) REFERENCES `cart_ordersmodel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_detailmodel`
--

LOCK TABLES `cart_detailmodel` WRITE;
/*!40000 ALTER TABLE `cart_detailmodel` DISABLE KEYS */;
INSERT INTO `cart_detailmodel` VALUES (1,'SSK    日本進口打擊頭盔    深藍   H5500-70',2080,1,2080,3),(2,'EVO XVT [WTV7115SC] 打擊頭盔 硬式棒球 安全 防護 舒適 包覆 通風 不悶熱 霧面 紅',1880,1,1880,4),(3,'鐵人牌18吋木棒(棒球棒/短球棍/打擊木棍/防衛球桿/防身棒/親子互動)',171,1,171,11),(4,'Wilson A200 10 EZ Catch [WBW10045610] 守備手套 兒童 壘球 棒球 10吋 藍紅',1180,1,1180,12),(5,'ZETT 成人捕手連罩式頭盔 BHMT-1811',2511,1,2511,13),(6,'MIZUNO 打擊手套-棒球 壘球 運動 美津濃 1EJEA09962 白紅藍',1134,1,1134,14),(7,'SSK  台灣製木製棒球棒   PW660',2700,1,2700,15),(8,'MIZUNO 棒球手套-外野手用-棒壘球  右投 美津濃 1ATGH22760-47 黃黑',2747,1,2747,16),(9,'SSK    日本進口打擊頭盔    深藍   H5500-70',2080,1,2080,17),(10,'EVO XVT Scion [WTV7010BL] 打擊頭盔 硬式棒球 安全 防護 舒適 包覆 亮面 黑',1680,1,1680,18),(11,'SSK    日本進口打擊頭盔    深藍   H5500-70',2080,2,4160,19),(12,'ZETT 成人捕手連罩式頭盔 BHMT-1811',2511,1,2511,19),(13,'EVO XVT Scion [WTV7010NA] 打擊頭盔 硬式棒球 安全 防護 舒適 包覆 亮面 深藍',1680,1,1680,20),(14,'SSK    日本進口打擊頭盔    深藍   H5500-70',2080,2,4160,20),(15,'Wilson A200 10 EZ Catch [WBW10045410] 守備手套 壘球 棒球 10吋 兒童 白紫',1180,1,1180,21),(16,'ZETT 手套專用箱 黑 BAT-77',1211,1,1211,21),(17,'Wilson A200 10 EZ Catch [WBW10045610] 守備手套 兒童 壘球 棒球 10吋 藍紅',1180,1,1180,22),(18,'MIZUNO 打擊手套-棒球 壘球 運動 美津濃 1EJEA09914 丈青藍白粉',1134,2,2268,22);
/*!40000 ALTER TABLE `cart_detailmodel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_ordersmodel`
--

DROP TABLE IF EXISTS `cart_ordersmodel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_ordersmodel` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `subtotal` int NOT NULL,
  `shipping` int NOT NULL,
  `grandtotal` int NOT NULL,
  `customname` varchar(100) NOT NULL,
  `customemail` varchar(100) NOT NULL,
  `customphone` varchar(50) NOT NULL,
  `customaddress` varchar(200) NOT NULL,
  `paytype` varchar(20) NOT NULL,
  `create_date` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_ordersmodel`
--

LOCK TABLES `cart_ordersmodel` WRITE;
/*!40000 ALTER TABLE `cart_ordersmodel` DISABLE KEYS */;
INSERT INTO `cart_ordersmodel` VALUES (1,2114,100,2214,'liu','liu@gmail.com','0987654321','taichung','ATM轉帳','2022-11-30 14:51:41.207913'),(2,2114,100,2214,'liu','liu@gmail.com','0987654321','taichung','ATM轉帳','2022-11-30 14:52:10.144432'),(3,2080,100,2180,'liu','liu@gmail.com','0987654321','taichung','ATM轉帳','2022-11-30 14:52:32.895876'),(4,1880,100,1980,'liu','liu@gmail.com','0987654321','taichung','ATM轉帳','2022-11-30 15:52:19.053422'),(5,0,100,100,'liu','liu@gmail.com','0987654321','taichung','ATM轉帳','2022-11-30 16:02:28.357848'),(6,0,100,100,'liu','liu@gmail.com','0987654321','taichung','ATM轉帳','2022-11-30 16:04:01.134711'),(7,0,100,100,'liu','liu@gmail.com','0987654321','taichung','ATM轉帳','2022-11-30 16:04:25.876975'),(8,0,100,100,'liu','liu@gmail.com','0987654321','taichung','ATM轉帳','2022-11-30 16:05:07.221652'),(9,0,100,100,'liu','liu@gmail.com','0987654321','taichung','ATM轉帳','2022-11-30 16:05:15.931672'),(10,0,100,100,'liu','liu@gmail.com','0987654321','taichung','ATM轉帳','2022-11-30 16:11:38.792877'),(11,171,100,271,'liu','liu@gmail.com','0987654321','taichung','信用卡','2022-11-30 16:19:09.979452'),(12,1180,100,1280,'liu','jyliu77@gmail.com','0987654321','tiachung','ATM轉帳','2022-12-25 16:25:40.161817'),(13,2511,100,2611,'liu','jyliu77@gmail.com','0987654321','tiachung','ATM轉帳','2022-12-25 16:35:44.241763'),(14,1134,100,1234,'liu','jyliu77@gmail.com','0987654321','tiachung','ATM轉帳','2022-12-25 16:49:56.171741'),(15,2700,100,2800,'liu','jyliu77@gmail.com','0987654321','tiachung','ATM轉帳','2022-12-25 16:54:57.482237'),(16,2747,100,2847,'liu','jyliu77@gmail.com','0987654321','tiachung','ATM轉帳','2022-12-25 16:57:34.975231'),(17,2080,100,2180,'lee','lee@gmail.com','0987654321','tiachung','ATM轉帳','2022-12-25 16:59:02.059194'),(18,1680,100,1780,'liu','jyliu77@gmail.com','0987654321','tiachung','ATM轉帳','2022-12-25 17:05:28.967992'),(19,6671,100,6771,'liu','jyliu77@gmail.com','0987654321','tiachung','ATM轉帳','2022-12-25 17:09:32.656846'),(20,5840,100,5940,'liu','jyliu77@gmail.com','0987654321','tiachung','ATM轉帳','2022-12-25 17:21:18.759731'),(21,2391,100,2491,'liu','jyliu77@gmail.com','0987654321','tiachung','ATM轉帳','2022-12-25 17:22:53.380554'),(22,3448,100,3548,'liu','jyliu77@gmail.com','0987654321','tiachung','ATM轉帳','2022-12-25 17:26:40.106469');
/*!40000 ALTER TABLE `cart_ordersmodel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `content` longtext NOT NULL,
  `create_date` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES (1,'liu','jyliu@gmail.com','0987654321','just test','2022-11-17 02:30:23.811208'),(2,'liu','jyliu@gmail.com','0987654321','test2','2022-11-17 07:04:01.338894'),(3,'liu','jyliu77@gmail.com','0987654321','test mail','2022-12-25 14:40:22.466474');
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpbl`
--

DROP TABLE IF EXISTS `cpbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cpbl` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `link` varchar(200) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `postdate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cpbl`
--

LOCK TABLES `cpbl` WRITE;
/*!40000 ALTER TABLE `cpbl` DISABLE KEYS */;
INSERT INTO `cpbl` VALUES (1,'吳哲源7局好投領銜 兄弟連兩年4連勝封王寫新猷','https://www.cpbl.com.tw/xmdoc/cont?sid=0M313861152084706860','https://www.cpbl.com.tw/files/file_pool/1/0m314001844253650032/17097141968602.jpg','2022-11-09'),(2,'鄭凱文7局優質先發奪勝 中信兄弟3勝聽牌','https://www.cpbl.com.tw/xmdoc/cont?sid=0M312825882769630974','https://www.cpbl.com.tw/files/file_pool/1/0m312826372820071589/0cl-inu8.jpeg','2022-11-08'),(3,'泰樂8局好投+陳子豪3分砲 兄弟斬猿連拿兩勝','https://www.cpbl.com.tw/xmdoc/cont?sid=0M310782197187281068','https://www.cpbl.com.tw/files/file_pool/1/0m310782497518170472/069a8243_1.jpg','2022-11-06'),(4,'德保拉7局優質先發 兄弟獲台灣大賽首戰獲勝','https://www.cpbl.com.tw/xmdoc/cont?sid=0M309785717826974119','https://www.cpbl.com.tw/files/file_pool/1/0m309786949804963471/069a6731.jpg','2022-11-05'),(5,'台灣大賽28人名單公布 「象猿大戰」火熱開打','https://www.cpbl.com.tw/xmdoc/cont?sid=0M307583731827909463','https://www.cpbl.com.tw/files/file_pool/1/0m307584131949735584/2022%e5%86%a0%e8%bb%8d%e8%b3%bd_28%e4%ba%ba%e5%90%8d%e5%96%ae-01.png','2022-11-03'),(6,'2022CPBL中華電信台灣大賽 巔峰對決週末點燃戰火','https://www.cpbl.com.tw/xmdoc/cont?sid=0M306597930210301622','https://www.cpbl.com.tw/files/file_pool/1/0m306598163223231627/2022%e5%86%a0%e8%bb%8d%e8%b3%bdlogo_%e5%ae%9aout.png','2022-11-02'),(7,'呂彥青關鍵守勝 兄弟1分差擊敗味全揮軍台灣大賽','https://www.cpbl.com.tw/xmdoc/cont?sid=0M304837085664848435','https://www.cpbl.com.tw/files/file_pool/1/0m304837308232184294/069a8752_1.jpg','2022-10-31'),(8,'鋼龍優質先發搶勝 龍隊延長季後賽戰線','https://www.cpbl.com.tw/xmdoc/cont?sid=0M303839466367507337','https://www.cpbl.com.tw/files/file_pool/1/0m303839941647780216/egg_7183.jpg','2022-10-30'),(9,'德保拉完投壓制龍 中信兄弟搶下第2勝聽牌','https://www.cpbl.com.tw/xmdoc/cont?sid=0M302741376932713250','https://www.cpbl.com.tw/files/file_pool/1/0m302741765007439733/bh1x3lvk.jpeg','2022-10-29'),(10,'38歲換隊再出發 王勝偉獲東山再起獎','https://www.cpbl.com.tw/xmdoc/cont?sid=0M301620343791220345','https://www.cpbl.com.tw/files/file_pool/1/0m301620664626393157/2022%e9%a0%92%e7%8d%8e%e5%85%b8%e7%a6%ae_%e7%a4%be%e7%be%a4_%e6%9d%b1%e5%b1%b1%e5%86%8d%e8%b5%b7%e7%8d%8e.png','2022-10-28'),(11,'季後賽28名單公布 「龍象大戰」29日點燃戰火','https://www.cpbl.com.tw/xmdoc/cont?sid=0M300594486894840072','https://www.cpbl.com.tw/files/file_pool/1/0m300594949982064859/2022%e5%ad%a3%e5%be%8c%e8%b3%bd_28%e4%ba%ba%e5%90%8d%e5%96%ae-01.png','2022-10-27'),(12,'辛元旭敲再見安 富邦悍將主場四連勝本季劃下句號','https://www.cpbl.com.tw/xmdoc/cont?sid=0M299825114895931242','https://www.cpbl.com.tw/files/file_pool/1/0m299832390325204139/yua06223.jpg','2022-10-26'),(13,'呂詠臻先發初登板 龍獅激戰12局言和','https://www.cpbl.com.tw/xmdoc/cont?sid=0M299497149348213823','https://www.cpbl.com.tw/files/file_pool/1/0m299499568331883170/test123.jpeg','2022-10-25'),(14,'辛元旭3打點拿下MVP 富邦6：2擊退樂天','https://www.cpbl.com.tw/xmdoc/cont?sid=0M299033110603941177','https://www.cpbl.com.tw/files/file_pool/1/0m299033858561953446/a2.jpg','2022-10-25'),(15,'壽星伍鐸勝投MVP 助龍隊完封悍將','https://www.cpbl.com.tw/xmdoc/cont?sid=0M298005866049088460','https://www.cpbl.com.tw/files/file_pool/1/0m298006155350832678/s__61653057.jpg','2022-10-24'),(16,'決戰季後賽 龍象大戰爭奪總冠軍賽門票','https://www.cpbl.com.tw/xmdoc/cont?sid=0M297521111546025715','https://www.cpbl.com.tw/files/file_pool/1/0m297567445038319516/s__61620307.jpg','2022-10-24'),(17,'杜家明生涯首轟繳猛打賞 中信奪單季69勝破隊史紀錄','https://www.cpbl.com.tw/xmdoc/cont?sid=0M296834618971863327','https://www.cpbl.com.tw/files/file_pool/1/0m296834930390591737/1023%20brvsrm.jpg','2022-10-23'),(18,'劉俊豪敲安護送超前分 生涯首度獲選MVP','https://www.cpbl.com.tw/xmdoc/cont?sid=0M296813025042953542','https://www.cpbl.com.tw/files/file_pool/1/0m296813699726594579/znsu8oza.jpeg','2022-10-23'),(19,'味全延長賽逼和樂天 送兄弟下半季非自力封王','https://www.cpbl.com.tw/xmdoc/cont?sid=0M296029189284539567','https://www.cpbl.com.tw/files/file_pool/1/0m296029936095683356/a2%20%282%29.jpg','2022-10-22'),(20,'稱霸2022中職二軍 富邦悍將隊史首冠','https://www.cpbl.com.tw/xmdoc/cont?sid=0M295620433629592686','https://www.cpbl.com.tw/files/file_pool/1/0m295710573505740189/930152.jpg','2022-10-22');
/*!40000 ALTER TABLE `cpbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datapost_document`
--

DROP TABLE IF EXISTS `datapost_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `datapost_document` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `file` varchar(100) NOT NULL,
  `upload_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datapost_document`
--

LOCK TABLES `datapost_document` WRITE;
/*!40000 ALTER TABLE `datapost_document` DISABLE KEYS */;
INSERT INTO `datapost_document` VALUES (1,'files/photo.jpg','2022-12-25'),(2,'files/YOONA.jpg','2022-12-25'),(3,'files/ps.jpg','2022-12-25'),(4,'files/HelloWorld.py','2022-12-25'),(5,'files/三爺.jpg','2022-12-25');
/*!40000 ALTER TABLE `datapost_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2022-11-17 07:10:41.893182','11','CPBL object (11)',1,'[{\"added\": {}}]',7,1),(2,'2022-11-17 07:11:28.497806','12','CPBL object (12)',1,'[{\"added\": {}}]',7,1),(3,'2022-11-17 07:11:58.357915','13','CPBL object (13)',1,'[{\"added\": {}}]',7,1),(4,'2022-11-17 07:12:25.413745','14','CPBL object (14)',1,'[{\"added\": {}}]',7,1),(5,'2022-11-17 07:13:11.797070','15','CPBL object (15)',1,'[{\"added\": {}}]',7,1),(6,'2022-11-17 07:13:32.729794','16','CPBL object (16)',1,'[{\"added\": {}}]',7,1),(7,'2022-11-17 07:13:55.459251','17','CPBL object (17)',1,'[{\"added\": {}}]',7,1),(8,'2022-11-17 07:14:18.844204','18','CPBL object (18)',1,'[{\"added\": {}}]',7,1),(9,'2022-11-17 07:14:41.777508','19','CPBL object (19)',1,'[{\"added\": {}}]',7,1),(10,'2022-11-17 07:15:02.533798','20','CPBL object (20)',1,'[{\"added\": {}}]',7,1),(11,'2022-11-21 02:38:25.378113','37','Product object (37)',3,'',9,1),(12,'2022-11-21 02:38:25.385740','36','Product object (36)',3,'',9,1),(13,'2022-11-21 02:38:25.392811','35','Product object (35)',3,'',9,1),(14,'2022-11-21 02:38:25.402950','34','Product object (34)',3,'',9,1),(15,'2022-11-21 02:38:25.411935','33','Product object (33)',3,'',9,1),(16,'2022-11-21 02:38:25.421037','32','Product object (32)',3,'',9,1),(17,'2022-11-21 02:38:25.431819','31','Product object (31)',3,'',9,1),(18,'2022-11-21 02:38:25.440885','30','Product object (30)',3,'',9,1),(19,'2022-11-21 02:38:25.449728','29','Product object (29)',3,'',9,1),(20,'2022-11-21 02:38:25.458447','28','Product object (28)',3,'',9,1),(21,'2022-11-21 02:38:25.467575','27','Product object (27)',3,'',9,1),(22,'2022-11-21 02:38:25.476946','26','Product object (26)',3,'',9,1),(23,'2022-11-21 02:38:25.485698','25','Product object (25)',3,'',9,1),(24,'2022-11-21 02:38:25.496271','24','Product object (24)',3,'',9,1),(25,'2022-11-21 02:38:25.506001','23','Product object (23)',3,'',9,1),(26,'2022-11-21 02:38:25.514755','22','Product object (22)',3,'',9,1),(27,'2022-11-21 02:38:25.524100','21','Product object (21)',3,'',9,1),(28,'2022-11-21 02:38:25.532765','20','Product object (20)',3,'',9,1),(29,'2022-11-21 02:38:25.544607','19','Product object (19)',3,'',9,1),(30,'2022-11-21 02:38:25.553530','18','Product object (18)',3,'',9,1),(31,'2022-11-21 02:38:25.562520','17','Product object (17)',3,'',9,1),(32,'2022-11-21 02:38:25.573615','16','Product object (16)',3,'',9,1),(33,'2022-11-21 02:38:25.581779','15','Product object (15)',3,'',9,1),(34,'2022-11-21 02:38:25.590673','14','Product object (14)',3,'',9,1),(35,'2022-11-21 02:38:25.599524','13','Product object (13)',3,'',9,1),(36,'2022-11-21 02:38:25.609660','12','Product object (12)',3,'',9,1),(37,'2022-11-21 02:38:25.620537','11','Product object (11)',3,'',9,1),(38,'2022-11-21 02:38:25.629431','10','Product object (10)',3,'',9,1),(39,'2022-11-21 02:38:25.638437','9','Product object (9)',3,'',9,1),(40,'2022-11-21 02:38:25.647241','8','Product object (8)',3,'',9,1),(41,'2022-11-21 02:38:25.656688','7','Product object (7)',3,'',9,1),(42,'2022-11-21 02:38:25.664642','6','Product object (6)',3,'',9,1),(43,'2022-11-21 02:38:25.673972','5','Product object (5)',3,'',9,1),(44,'2022-11-21 02:38:25.687937','4','Product object (4)',3,'',9,1),(45,'2022-11-21 02:38:25.695539','3','Product object (3)',3,'',9,1),(46,'2022-11-21 02:38:25.702674','2','Product object (2)',3,'',9,1),(47,'2022-11-21 02:38:25.709934','1','Product object (1)',3,'',9,1),(48,'2022-11-30 16:18:40.665475','40','Product object (40)',2,'[{\"changed\": {\"fields\": [\"Photo\"]}}]',9,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(11,'cart','detailmodel'),(10,'cart','ordersmodel'),(5,'contenttypes','contenttype'),(13,'datapost','document'),(8,'message','contact'),(7,'news','cpbl'),(12,'persons','person'),(6,'sessions','session'),(9,'shop','product');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2022-11-16 02:25:01.855927'),(2,'auth','0001_initial','2022-11-16 02:25:03.425726'),(3,'admin','0001_initial','2022-11-16 02:25:03.863181'),(4,'admin','0002_logentry_remove_auto_add','2022-11-16 02:25:03.878748'),(5,'admin','0003_logentry_add_action_flag_choices','2022-11-16 02:25:03.894346'),(6,'contenttypes','0002_remove_content_type_name','2022-11-16 02:25:04.129144'),(7,'auth','0002_alter_permission_name_max_length','2022-11-16 02:25:04.269933'),(8,'auth','0003_alter_user_email_max_length','2022-11-16 02:25:04.426236'),(9,'auth','0004_alter_user_username_opts','2022-11-16 02:25:04.441769'),(10,'auth','0005_alter_user_last_login_null','2022-11-16 02:25:04.566814'),(11,'auth','0006_require_contenttypes_0002','2022-11-16 02:25:04.582434'),(12,'auth','0007_alter_validators_add_error_messages','2022-11-16 02:25:04.598009'),(13,'auth','0008_alter_user_username_max_length','2022-11-16 02:25:04.847923'),(14,'auth','0009_alter_user_last_name_max_length','2022-11-16 02:25:05.004137'),(15,'auth','0010_alter_group_name_max_length','2022-11-16 02:25:05.177406'),(16,'auth','0011_update_proxy_permissions','2022-11-16 02:25:05.193063'),(17,'auth','0012_alter_user_first_name_max_length','2022-11-16 02:25:05.333674'),(18,'sessions','0001_initial','2022-11-16 02:25:05.458569'),(19,'news','0001_initial','2022-11-16 05:47:32.675572'),(20,'message','0001_initial','2022-11-17 00:53:44.424517'),(21,'shop','0001_initial','2022-11-21 02:24:06.182177'),(22,'cart','0001_initial','2022-11-30 12:18:41.882481'),(23,'persons','0001_initial','2022-12-17 16:45:55.030317'),(24,'datapost','0001_initial','2022-12-25 14:52:35.176789');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('4k7oaem1au1hx4z12g1s6h31t1ohbx1w','eyJjYXJ0bGlzdCI6W119:1p0IJC:ww7_9hPMEJK69qIfG9tqrVgwo7WUTVdAw0eaa_UXP3o','2022-12-14 16:19:10.001953'),('8wgdxucu4if18e6ng8264yupcmh7veto','eyJjYXJ0bGlzdCI6W119:1p9NHV:nDBxE_9gfzVTxngtvJjvyOdWjS5BoxBDuL2ZX3UdA68','2023-01-08 17:26:57.372798'),('lj3ua3fw84kipmur8rd8xt9q5jwb5tc9','eyJjYXJ0bGlzdCI6W119:1p9N5h:tTNYuwtPOHGSEaR-85YdvlwAFecQhlYSQdMT_c-neT0','2023-01-08 17:14:45.321005');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personmember`
--

DROP TABLE IF EXISTS `personmember`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personmember` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `sex` varchar(2) NOT NULL,
  `birthday` date NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `create_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personmember`
--

LOCK TABLES `personmember` WRITE;
/*!40000 ALTER TABLE `personmember` DISABLE KEYS */;
INSERT INTO `personmember` VALUES (1,'liu','M','1999-01-01','liu@gmail.com','taichung','1d6442ddcfd9db1ff81df77cbefcd5afcc8c7ca952ab3101ede17a84b866d3f3','2022-12-17'),(2,'liu','F','1999-01-01','liu1@gmail.com','taichung','1657333ad629bf4331f12362d6b1523f273368afa4e69473586265b6de4a2e56','2022-12-17'),(3,'liu','F','1999-01-01','liu11@gmail.com','taichung','1657333ad629bf4331f12362d6b1523f273368afa4e69473586265b6de4a2e56','2022-12-17'),(4,'liu','F','1999-01-01','liu0@gmail.com','taichung','1657333ad629bf4331f12362d6b1523f273368afa4e69473586265b6de4a2e56','2022-12-17'),(5,'liu','F','1999-01-01','liu00@gmail.com','taichung','b3464291a58f65050d16b715a13e1c4d422785e733f7a9c44e381dfe620b5855','2022-12-17'),(6,'liu','F','1999-01-01','liu01@gmail.com','taichung','4410fc15c5a3cde7a2b5366a41dbc95e6547a6021efdff98cfcd5e875e8c3c70','2022-12-17'),(7,'lee','F','1999-01-01','lee@gmail.com','taichung','1d6442ddcfd9db1ff81df77cbefcd5afcc8c7ca952ab3101ede17a84b866d3f3','2022-12-18'),(8,'liuchunyi','M','1988-11-23','jyliu77@gmail.com','taichung','ba78de90eb879a43cd847013bfb4c4ac844d848cc6f998b39f33c06a98d5f538','2022-12-25');
/*!40000 ALTER TABLE `personmember` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop`
--

DROP TABLE IF EXISTS `shop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `link` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `price` int NOT NULL,
  `create_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop`
--

LOCK TABLES `shop` WRITE;
/*!40000 ALTER TABLE `shop` DISABLE KEYS */;
INSERT INTO `shop` VALUES (38,'SSK  美國進口木製棒球棒    US-B01','https://tw.buy.yahoo.com/gdsale/SSK-美國進口木製棒球棒-US-B01-9107938.html','https://s.yimg.com/zp/MerchandiseImages/67D0805255-SP-8742441.jpg',4800,'2022-11-21'),(39,'SSK  台灣製木製棒球棒   PS760','https://tw.buy.yahoo.com/gdsale/SSK-台灣製木製棒球棒-PS760-9107877.html','https://s.yimg.com/zp/MerchandiseImages/8065CBE406-SP-8745160.jpg',2080,'2022-11-21'),(40,'鐵人牌18吋木棒(棒球棒/短球棍/打擊木棍/防衛球桿/防身棒/親子互動)','https://tw.buy.yahoo.com/gdsale/gdsale.asp?gdid=p0042236248801','https://s.yimg.com/ut/api/res/1.2/nj_DnaoA1sem.Wd5ztypSg--~B/YXBwaWQ9eXR3bWFsbDtjYz0zMTUzNjAwMDtoPTYwMDtxPTEwMDt3PTYwMA--/https://s.yimg.com/fy/02d1/item/p0042236248801-item-9da2xf4x0800x0800-m.jpg',171,'2022-11-21'),(41,'SSK  台灣製木製棒球棒   勃根地紅   PRO500P-22','https://tw.buy.yahoo.com/gdsale/SSK-台灣製木製棒球棒-勃根地紅-PRO500P-22-9107882.html','https://s.yimg.com/zp/MerchandiseImages/E2023F688D-SP-8744640.jpg',2940,'2022-11-21'),(42,'SSK  台灣製木製棒球棒   霧黑   PRO500P-90','https://tw.buy.yahoo.com/gdsale/SSK-台灣製木製棒球棒-霧黑-PRO500P-90-9107885.html','https://s.yimg.com/zp/MerchandiseImages/C54883BCD7-SP-8744611.jpg',2940,'2022-11-21'),(43,'SSK  台灣製木製棒球棒   PRO550P','https://tw.buy.yahoo.com/gdsale/SSK-台灣製木製棒球棒-PRO550P-9107884.html','https://s.yimg.com/zp/MerchandiseImages/364F58AD9D-SP-8744539.jpg',3180,'2022-11-21'),(44,'SSK  台灣製木製棒球棒   PW660','https://tw.buy.yahoo.com/gdsale/SSK-台灣製木製棒球棒-PW660-9107880.html','https://s.yimg.com/zp/MerchandiseImages/041FE39508-SP-8745114.jpg',2700,'2022-11-21'),(45,'BAT 28吋輕量少棒棒球鋁棒 球棒 野球 壘球 -四色可選','https://tw.buy.yahoo.com/gdsale/BAT-28吋輕量少棒棒球鋁棒-野球-壘球-6729951.html','https://s.yimg.com/zp/images/F7AA4F5967494A71C4DD8BC51851C6CB09542054',490,'2022-11-21'),(46,'Ahoye 棒球手套 12.5吋 壘球手套','https://tw.buy.yahoo.com/gdsale/Ahoye-棒球手套-12-5吋-壘球手套-9426355.html','https://s.yimg.com/zp/MerchandiseImages/0FAA80499B-SP-9610842.jpg',649,'2022-11-21'),(47,'MIZUNO 棒球手套-外野手用-棒壘球  右投 美津濃 1ATGH22760-47 黃黑','https://tw.buy.yahoo.com/gdsale/MIZUNO-棒球手套-外野手用-棒壘球-右投-美-10226704.html','https://s.yimg.com/zp/MerchandiseImages/B14E8DF0DF-SP-12174181.jpg',2747,'2022-11-21'),(48,'Wilson A200 [WBW10020510] 兒童 守備手套 壘球 棒球 內野 外野 10吋 正手 黑紅','https://tw.buy.yahoo.com/gdsale/Wilson-A200-WBW10020510-兒童-守備手套-壘球-棒球-內野-外野-10吋-9946988.html','https://s.yimg.com/zp/MerchandiseImages/A4ADA1C938-SP-11173314.jpg',980,'2022-11-21'),(49,'Wilson A200 10 EZ Catch [WBW10045510] 守備手套 壘球 棒球 10吋 兒童 黑紅','https://tw.buy.yahoo.com/gdsale/Wilson-A200-10-EZ-Catch-WBW10045510-守備手套-壘球-棒球-10146391.html','https://s.yimg.com/zp/MerchandiseImages/AACBC51041-SP-11869525.jpg',1180,'2022-11-21'),(50,'Wilson A200 [WBW10020410] 兒童 守備手套 壘球 棒球 內野 外野 10吋 正手 黑白','https://tw.buy.yahoo.com/gdsale/Wilson-A200-WBW10020410-兒童-守備手套-壘球-棒球-內野-外野-10吋-9946956.html','https://s.yimg.com/zp/MerchandiseImages/FF08136DA0-SP-11172605.jpg',980,'2022-11-21'),(51,'Wilson A200 [WTA02RB19AS] 兒童 守備手套 壘球 棒球 內野 外野 10吋 正手 灰藍','https://tw.buy.yahoo.com/gdsale/Wilson-A200-WTA02RB19AS-兒童-守備手套-壘球-棒球-內野-外野-10吋-9946991.html','https://s.yimg.com/zp/MerchandiseImages/659F0E2548-SP-11173317.jpg',980,'2022-11-21'),(52,'Wilson A200 [WBW10020610] 兒童 守備手套 壘球 棒球 內野 外野 10吋 正手 紅藍','https://tw.buy.yahoo.com/gdsale/Wilson-A200-WBW10020610-兒童-守備手套-壘球-棒球-內野-外野-10吋-9946989.html','https://s.yimg.com/zp/MerchandiseImages/7C9EBA7AB2-SP-11173316.jpg',980,'2022-11-21'),(53,'ZETT 手套專用箱 黑 BAT-77','https://tw.buy.yahoo.com/gdsale/ZETT-手套專用箱-黑-BAT-77-9061198.html','https://s.yimg.com/zp/MerchandiseImages/10E2E5F116-SP-8621514.jpg',1211,'2022-11-21'),(54,'Wilson A200 [WBW10022410] 兒童 守備手套 壘球 棒球 內野 外野 10吋 反手 紅藍','https://tw.buy.yahoo.com/gdsale/Wilson-A200-WBW10022410-兒童-守備手套-壘球-棒球-內野-外野-10吋-9946937.html','https://s.yimg.com/zp/MerchandiseImages/8F0DCB3704-SP-11172424.jpg',980,'2022-11-21'),(55,'SSK   守備手套  黑色   BG120A-9090','https://tw.buy.yahoo.com/gdsale/SSK-守備手套-黑色-BG120A-9090-9125027.html','https://s.yimg.com/zp/MerchandiseImages/FFC2DF9C5D-SP-8779562.jpg',400,'2022-11-21'),(56,'MIZUNO 打擊手套-棒球 壘球 運動 美津濃 1EJEA09914 丈青藍白粉','https://tw.buy.yahoo.com/gdsale/MIZUNO-打擊手套-棒球-壘球-運動-美津濃--10017703.html','https://s.yimg.com/zp/MerchandiseImages/352E7E1592-SP-11388752.jpg',1134,'2022-11-21'),(57,'MIZUNO 打擊手套-棒球 壘球 運動 美津濃 1EJEA09909 白黑金','https://tw.buy.yahoo.com/gdsale/MIZUNO-打擊手套-棒球-壘球-運動-美津濃--10017702.html','https://s.yimg.com/zp/MerchandiseImages/1FAEAF2DD6-SP-11388751.jpg',1134,'2022-11-21'),(58,'MIZUNO 打擊手套-棒球 壘球 運動 美津濃 1EJEA09962 白紅藍','https://tw.buy.yahoo.com/gdsale/MIZUNO-打擊手套-棒球-壘球-運動-美津濃--10017704.html','https://s.yimg.com/zp/MerchandiseImages/1414F300A1-SP-11388756.jpg',1134,'2022-11-21'),(59,'Wilson A200 10 EZ Catch [WBW10045410] 守備手套 壘球 棒球 10吋 兒童 白紫','https://tw.buy.yahoo.com/gdsale/Wilson-A200-10-EZ-Catch-WBW10045410-守備手套-壘球-棒球-10146388.html','https://s.yimg.com/zp/MerchandiseImages/5D1030E198-SP-11869466.jpg',1180,'2022-11-21'),(60,'Wilson A200 10 EZ Catch [WBW10045610] 守備手套 兒童 壘球 棒球 10吋 藍紅','https://tw.buy.yahoo.com/gdsale/Wilson-A200-10-EZ-Catch-WBW10045610-守備手套-兒童-壘球-棒球-10146393.html','https://s.yimg.com/zp/MerchandiseImages/C1DE746288-Gd-9858230.jpg',1180,'2022-11-21'),(61,'EVO XVT [WTV7115RO] 打擊頭盔 硬式棒球 安全 防護 舒適 包覆 通風 霧面 寶藍','https://tw.buy.yahoo.com/gdsale/EVO-XVT-WTV7115RO-打擊頭盔-硬式棒球-安全-防護-舒適-包覆-通風-霧面-寶藍-10116440.html','https://s.yimg.com/zp/MerchandiseImages/061C2B9FF6-SP-11738397.jpg',1880,'2022-11-21'),(62,'EVO XVT [WTV7115BL] 打擊頭盔 硬式棒球 安全 防護 舒適 包覆 通風 不悶熱 霧面 黑','https://tw.buy.yahoo.com/gdsale/EVO-XVT-WTV7115BL-打擊頭盔-硬式棒球-安全-防護-舒適-包覆-通風-不悶熱-霧面-10116442.html','https://s.yimg.com/zp/MerchandiseImages/E658F181ED-SP-11738405.jpg',1880,'2022-11-21'),(63,'EVO XVT [WTV7110NA] 打擊頭盔 硬式棒球 安全 防護 舒適 包覆 通風 不悶熱 亮面 深藍','https://tw.buy.yahoo.com/gdsale/EVO-XVT-WTV7110NA-打擊頭盔-硬式棒球-安全-防護-舒適-包覆-通風-不悶熱-亮面-10116438.html','https://s.yimg.com/zp/MerchandiseImages/8266C8DC83-SP-11738395.jpg',1880,'2022-11-21'),(64,'EVO XVT [WTV7115SC] 打擊頭盔 硬式棒球 安全 防護 舒適 包覆 通風 不悶熱 霧面 紅','https://tw.buy.yahoo.com/gdsale/EVO-XVT-WTV7115SC-打擊頭盔-硬式棒球-安全-防護-舒適-包覆-通風-不悶熱-霧面-10116443.html','https://s.yimg.com/zp/MerchandiseImages/EF016C43A5-SP-11738396.jpg',1880,'2022-11-21'),(65,'EVO XVT [WTV7110SC] 打擊頭盔 硬式棒球 安全 防護 舒適 包覆 通風 不悶熱 亮面 紅','https://tw.buy.yahoo.com/gdsale/EVO-XVT-WTV7110SC-打擊頭盔-硬式棒球-安全-防護-舒適-包覆-通風-不悶熱-亮面-10115820.html','https://s.yimg.com/zp/MerchandiseImages/B52F6B62B8-SP-11730143.jpg',1880,'2022-11-21'),(66,'EVO XVT [WTV7110BL] 打擊頭盔 硬式棒球 安全 防護 舒適 包覆 通風 不悶熱 亮面 黑','https://tw.buy.yahoo.com/gdsale/EVO-XVT-WTV7110BL-打擊頭盔-硬式棒球-安全-防護-舒適-包覆-通風-不悶熱-亮面-10116437.html','https://s.yimg.com/zp/MerchandiseImages/284CBDA3DA-SP-11738391.jpg',1880,'2022-11-21'),(67,'EVO XVT [WTV7115NA] 打擊頭盔 硬式棒球 安全 防護 舒適 包覆 通風 不悶熱 霧面 深藍','https://tw.buy.yahoo.com/gdsale/EVO-XVT-WTV7115NA-打擊頭盔-硬式棒球-安全-防護-舒適-包覆-通風-不悶熱-霧面-10116441.html','https://s.yimg.com/zp/MerchandiseImages/1116E00D6F-SP-11738403.jpg',1880,'2022-11-21'),(68,'EVO XVT [WTV7110RO] 打擊頭盔 硬式棒球 安全 防護 舒適 包覆 通風 不悶熱 亮面 寶藍','https://tw.buy.yahoo.com/gdsale/EVO-XVT-WTV7110RO-打擊頭盔-硬式棒球-安全-防護-舒適-包覆-通風-不悶熱-亮面-10116435.html','https://s.yimg.com/zp/MerchandiseImages/8DBD63A706-SP-11738381.jpg',1880,'2022-11-21'),(69,'EVO XVT Scion [WTV7010BL] 打擊頭盔 硬式棒球 安全 防護 舒適 包覆 亮面 黑','https://tw.buy.yahoo.com/gdsale/EVO-XVT-Scion-WTV7010BL-打擊頭盔-硬式棒球-安全-防護-舒適-包覆-亮面-10123113.html','https://s.yimg.com/zp/MerchandiseImages/DCD564D407-SP-11765658.jpg',1680,'2022-11-21'),(70,'EVO XVT Scion [WTV7010RO] 打擊頭盔 硬式棒球 安全 防護 舒適 包覆 亮面 寶藍','https://tw.buy.yahoo.com/gdsale/EVO-XVT-Scion-WTV7010RO-打擊頭盔-硬式棒球-安全-防護-舒適-包覆-亮面-10123135.html','https://s.yimg.com/zp/MerchandiseImages/3835AC4A50-SP-11765688.jpg',1680,'2022-11-21'),(71,'EVO XVT Scion [WTV7010SC] 打擊頭盔 硬式棒球 安全 防護 舒適 包覆 亮面 紅','https://tw.buy.yahoo.com/gdsale/EVO-XVT-Scion-WTV7010SC-打擊頭盔-硬式棒球-安全-防護-舒適-包覆-亮面-10123136.html','https://s.yimg.com/zp/MerchandiseImages/F81769FDDB-SP-11765692.jpg',1680,'2022-11-21'),(72,'EVO XVT Scion [WTV7010NA] 打擊頭盔 硬式棒球 安全 防護 舒適 包覆 亮面 深藍','https://tw.buy.yahoo.com/gdsale/EVO-XVT-Scion-WTV7010NA-打擊頭盔-硬式棒球-安全-防護-舒適-包覆-亮面-10123115.html','https://s.yimg.com/zp/MerchandiseImages/B13B4FA7A7-SP-11765660.jpg',1680,'2022-11-21'),(73,'ZETT 成人捕手連罩式頭盔 BHMT-1811','https://tw.buy.yahoo.com/gdsale/ZETT-成人捕手連罩式頭盔-BHMT-1811-9057475.html','https://s.yimg.com/zp/MerchandiseImages/E465BA6C83-SP-8619436.jpg',2511,'2022-11-21'),(74,'SSK    日本進口打擊頭盔    深藍   H5500-70','https://tw.buy.yahoo.com/gdsale/SSK-日本進口打擊頭盔-深藍-H5500-70-9125024.html','https://s.yimg.com/zp/MerchandiseImages/2E7BE70BAC-SP-8781482.jpg',2080,'2022-11-21');
/*!40000 ALTER TABLE `shop` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-25 22:29:20
