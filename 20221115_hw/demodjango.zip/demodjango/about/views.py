from django.shortcuts import render

# Create your views here.

def brother(request):
    return render(request,'about.html')