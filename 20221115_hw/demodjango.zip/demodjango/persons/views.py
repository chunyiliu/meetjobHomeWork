from django.shortcuts import render

# Create your views here.
from .models import Person
import hashlib
from django.http import HttpResponseRedirect,HttpResponse
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
from email.mime.image import MIMEImage
from pathlib import Path
import os
def login(request):
    
    msg=''
    if 'email' in request.POST:
        email=request.POST['email']
        password=request.POST['password']

        password=hashlib.sha3_256(password.encode('utf-8')).hexdigest()
        
        obj=Person.objects.filter(email=email,password=password).count()
        if obj > 0:
            request.session['myMail']=email
            request.session['isAlive']=True
            people=Person.objects.get(email=email)
            if people.sex =='F':
                sex='小姐'
            else:
                sex='先生'
            msg="歡迎登入{} {}".format(people.name,sex)
            
            
            return render(request,'login.html',locals())
        else:
            msg="帳密錯誤,請重新輸入"
            return render(request,'login.html',locals())
    else:
        if "myMail" in request.session and "isAlive" in request.session:
            return HttpResponseRedirect('/')
        else:
            return render(request,'login.html',locals())
        
def logout(request):
    if "myMail" in request.session and "isAlive" in request.session:
        del request.session["isAlive"] #刪除SESSION內容
        del request.session["myMail"]
    
        return HttpResponseRedirect('/login')
    else:
        return HttpResponseRedirect('/login')
    
def register(request):
    msg=''
    
    if "uName"in request.POST:
        username=request.POST['uName']
        usersex=request.POST['uSex']
        userbirthday=request.POST['uBir']
        useremail=request.POST['uEmail']
        useraddress=request.POST['uAddr']
        userpassword=request.POST['uPwd']
        
        userpassword=hashlib.sha3_256(userpassword.encode('utf-8')).hexdigest()
        
        obj=Person.objects.filter(email=useremail).count()
        
        if obj == 0: #表示這個email沒有註冊過
            #新增會員資料
            Person.objects.create(name=username,sex=usersex,birthday=userbirthday,email=useremail,password=userpassword,address=useraddress)
            msg="恭喜你,已完成註冊"
        
        else:
            msg="此Email 已經存在,請換一個mail註冊"
            
    return render(request,'register.html',locals())

def forget(request):
    msg=''
    
    if 'email' in request.POST:
        email=request.POST['email']
        
        obj=Person.objects.filter(email=email).count()
        if obj > 0:
            newpwd='123456'
            newpwd=hashlib.sha3_256(newpwd.encode('utf-8')).hexdigest()
            people=Person.objects.get(email=email)
            people.password=newpwd
            people.save()
            
            sendMail(email,'123456')
            msg="密碼已傳送到你的信箱 請重新登入"
        else:
            msg='找不到該名使用者'
    return render(request,'forget.html',locals())       
            
def sendMail(email,newpwd):
    #建立MIMEMultipart物件
    content = MIMEMultipart()
    
    #郵件標題
    content["subject"] = "NewPassword"
    #寄件者
    content["from"] = "jyliu77@gmail.com"
    #收件者
    content["to"] = email
    #郵件內容
    content.attach(MIMEText(newpwd))
    
    #郵件圖片內容
    img_dir = 'static/images/'
    image = 'YOONA.jpg'
    file_path = os.path.join(img_dir, image)
    content.attach(MIMEImage(Path(file_path).read_bytes()))
    with smtplib.SMTP(host="smtp.gmail.com", port="587") as smtp:  # 設定SMTP伺服器
        try:
            smtp.ehlo()  # 驗證SMTP伺服器
            smtp.starttls()  # 建立加密傳輸
            smtp.login("jyliu77@gmail.com", "qijbuqyxhgyknapx")  # 登入寄件者gmail
            smtp.send_message(content)  # 寄送郵件
            print("Complete!")
        except Exception as e:
            print("Error message: ", e)            
            
def changepwd(request):
    
    if "myMail" in request.session and "isAlive" in request.session:
        msg=''
        if 'oldpwd' in request.POST:
            oldpwd=request.POST['oldpwd']
            newpwd=request.POST['newpwd']
        
            oldpwd = hashlib.sha3_256(oldpwd.encode('utf-8')).hexdigest()
            newpwd = hashlib.sha3_256(newpwd.encode('utf-8')).hexdigest()
            
            email = request.session['myMail']
            
            obj=Person.objects.filter(email=email,password=oldpwd).count()
            
            if obj>0:
                #更新密碼
                user=Person.objects.get(email=email)
                user.password=newpwd
                user.save()
                msg="密碼變更完成"
            else:
                msg="舊密碼不正確,請重新輸入"
        
        return render(request,'changepwd.html',locals())
    else:       
        return HttpResponseRedirect('/login')
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            