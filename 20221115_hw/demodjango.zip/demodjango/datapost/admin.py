from django.contrib import admin

# Register your models here.

from .models import Document

class FileAdmin(admin.ModelAdmin):
	list_display = ('file','upload_date')

admin.site.register(Document,FileAdmin)