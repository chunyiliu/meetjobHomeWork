from django import forms

from .models import Document

class UploadModelForm(forms.ModelForm):
	class Meta:
		model=Document
		fields=('file',)
		widgets={
			'file':forms.FileInput(attrs={'class':'form-control-file'})
		}