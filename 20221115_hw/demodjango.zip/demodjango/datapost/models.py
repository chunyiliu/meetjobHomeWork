from django.db import models

# Create your models here.
from django.utils  import timezone

class Document(models.Model):
	file=models.FileField(upload_to='files/',blank=False,null=False)
	upload_date=models.DateField(default=timezone.now)