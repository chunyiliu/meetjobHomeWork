from django.apps import AppConfig


class DatapostConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "datapost"
