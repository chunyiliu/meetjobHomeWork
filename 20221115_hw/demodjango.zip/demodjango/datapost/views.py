from django.shortcuts import render,redirect

# Create your views here.
import os
from django.conf import settings
from .forms import UploadModelForm
from .models import Document

def postdata(request):
	files=Document.objects.all()
	form =UploadModelForm()
	if request.method =='POST':
		form = UploadModelForm(request.POST,request.FILES)
		if form.is_valid():
			form.save()
			return redirect('/datapost')
	context={
		'files':files,
		'form':form
	}
	datafile=os.listdir(settings.MEDIA_ROOT)
	return render(request,'postdata.html',locals())