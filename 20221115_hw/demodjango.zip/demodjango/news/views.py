from django.shortcuts import render
import requests
# Create your views here.
from datetime import datetime
import json
from .models import CPBL
from django.core.paginator import Paginator,EmptyPage,PageNotAnInteger

def news(request):
    
    news=CPBL.objects.all().order_by('id')
    
    paginator=Paginator(news,6)
    
    page=request.GET.get('page')
    
    try:
        data=paginator.page(page)
    except PageNotAnInteger:
        data=paginator.page(1)
    except EmptyPage:
        data=paginator.page(paginator.num_pages)
    
    
    
    content={'newslist':data}
    
    return render(request,'news.html',content)


def index(request):
    def TodayInfo(Info):
        D=Info[t]['startTime'].split()[0]
        return D,Info[t]['startTime'].split()[1]+'~'+Info[t]['endTime'].split()[1],Info[t]['elementValue'][0]['value']

    def BigT(Temp):
        D=Temp[t]['startTime'].split()[0]
        return D,Temp[t]['startTime'].split()[1]+'~'+Temp[t]['endTime'].split()[1],Temp[t]['elementValue'][0]['value']
    def SmallT(Temp):
        D=Temp[t]['startTime'].split()[0]
        return D,Temp[t]['startTime'].split()[1]+'~'+Temp[t]['endTime'].split()[1],Temp[t]['elementValue'][0]['value']
    def MeanT(Temp):
        D=Temp[t]['startTime'].split()[0]
        return D,Temp[t]['startTime'].split()[1]+'~'+Temp[t]['endTime'].split()[1],Temp[t]['elementValue'][0]['value']

    api="CWB-3DEC6CB1-BB37-4E63-8CED-8157B78D0240"
    url="https://opendata.cwb.gov.tw/api/v1/rest/datastore/F-D0047-075?Authorization={}".format(api)
    response = requests.get(url)
    now=datetime.now()
    now=now.strftime("%Y-%m-%d")
    if response.status_code==200:
        data = json.loads(response.text)
        location = data["records"]["locations"][0]["location"][2]["locationName"]
        Todaytitle=data["records"]["locations"][0]["location"][2]["weatherElement"][10]['description']
        Todayitem=data["records"]["locations"][0]["location"][2]["weatherElement"][10]['time']

        MeanTitle=data["records"]["locations"][0]["location"][2]["weatherElement"][1]['description']
        MinTitle=data["records"]["locations"][0]["location"][2]["weatherElement"][8]['description']
        MaxTitle=data["records"]["locations"][0]["location"][2]["weatherElement"][12]['description']

        MeanTemp=data["records"]["locations"][0]["location"][2]["weatherElement"][1]['time']
        MinTemp=data["records"]["locations"][0]["location"][2]["weatherElement"][8]['time']
        MaxTemp=data["records"]["locations"][0]["location"][2]["weatherElement"][12]['time']
        timeD=[]
        tempM=[]
        tempB=[]
        tempS=[]

        for t in range(len(MeanTemp)):
            if t%2==0:
                Meant=MeanT(MeanTemp)
                Mint=SmallT(MinTemp)
                Maxt=BigT(MaxTemp)
                today=TodayInfo(Todayitem)
                titleM=MeanTitle
                titleB=MaxTitle
                titleS=MinTitle
                timeD.append(Meant[0])
                tempM.append(int(Meant[2]))
                tempB.append(int(Maxt[2]))
                tempS.append(int(Mint[2]))
                if now==today[0]:
                    Today=today[2]
                    Today=Today.split('。')
                else:
                    pass

    

    return  render (request,'index.html',locals())

def award(request):
    return  render (request,'award.html')

def taiwanseries(request):
    return  render (request,'taiwanseries.html')