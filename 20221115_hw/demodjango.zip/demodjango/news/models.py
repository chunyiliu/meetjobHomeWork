from django.db import models

# Create your models here.

class CPBL(models.Model):
    title=models.CharField(max_length=100)
    link=models.CharField(max_length=200)
    photo=models.CharField(max_length=200)
    postdate=models.DateField()
    
    class Meta:
        db_table='cpbl'