# -*- coding: utf-8 -*-
"""
Created on Mon Nov 21 09:53:33 2022

@author: User
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Oct 14 09:40:06 2022

@author: User
"""

import requests
from bs4 import BeautifulSoup
import db
from datetime import datetime

def photo(txt):
    data=requests.get(txt).text

    soup=BeautifulSoup(data,'html.parser')
    
    img=soup.find('img').get('src')
    
    return img

today=datetime.now()
todays=today.strftime('%Y-%m-%d')
# print(todays)

url="https://tw.buy.yahoo.com/search/product"

payload={'p':'棒球頭盔'}

data=requests.get(url,params=payload).text

soup=BeautifulSoup(data,'html.parser')

goods=soup.find_all('ul',class_="gridList")[-1]

allgoods=goods.find_all('a','sc-gsWcmt grZHMV')
# print(goods)

cursor=db.conn.cursor()

for row in allgoods:

    link=row.get('href')
    photos=photo(link)
    #photo=row.find('img','sc-jcwpoC sc-carFqZ hVbAH eXRLKi')
    title=row.find('span','sc-jffHpj sc-eJocfa sc-dFRpbK fOVkIt cTZOQO fGWTiH').text
    price=row.find('span','sc-jffHpj bWOsJI').text
    price=price.replace('$','').replace(',','')
    
    # photos=photo.split()[0]
    
    print(link)
    print(photos)
    print(title)
    print(price)
    print()


    sql = "select * from shop where title='{}' ".format(title)
    
    cursor.execute(sql)
    
    db.conn.commit()
    
    if cursor.rowcount==0: #表示沒有該產品
        sql="insert into shop(title,price,link,photo,create_date) values('{}','{}','{}','{}','{}')".format(title,price,link,photos,todays)
    
        cursor.execute(sql)
        db.conn.commit()
    
    
db.conn.close()   
