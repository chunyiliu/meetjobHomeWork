from django.shortcuts import render,redirect

# Create your views here.
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
from email.mime.image import MIMEImage
from pathlib import Path
import os
from django.http import HttpResponseRedirect
from cart import models
from shop.models import Product

cartlist=list()
customname=''
customemail=''
customphone=''
customaddress=''

orderTotal=0
goodsTitle=list()

def addtocart(request,ctype=None,shopid=None):
    global cartlist
    
    if ctype=='add':
        goods=Product.objects.get(id=shopid)
        
        flag=True
        
        for unit in cartlist:
            if goods.title == unit[0]:
                unit[2]=str(int(unit[2])+1)
                unit[3]=str(int(unit[3])+goods.price)
                flag=False
                break
            
        if flag:
            templist=list()
            templist.append(goods.title)
            templist.append(str(goods.price))
            templist.append('1')
            templist.append(str(goods.price))
            cartlist.append(templist)
            
        request.session['cartlist']=cartlist
        
        return redirect('/cart/')
    
    elif ctype=="update":
        n=0
        for unit in cartlist:
            amount=request.POST.get('qty'+str(n),'1')
            if len(amount)==0:#留空未填
                amount='1'
            elif not amount.isnumeric():
                amount='1'
            elif int(amount)<=0:
                amount='1'
            unit[2]=amount
            unit[3]=str(int(unit[1]) * int(unit[2]))
            n+=1
            
        request.session['cartlist']=cartlist
        
        return redirect('/cart/')
    
    elif ctype=='empty':
        cartlist=list()
        request.session['cartlist']=cartlist
        
        return redirect('/cart/')    
    
    elif ctype=="remove":
        del cartlist[int(shopid)] #將被入的商品索引值刪除
        request.session['cartlist']=cartlist
        
        return redirect('/cart/')
    
    
def cart(request):
    global cartlist
    allcart=cartlist
    total=0
    for unit in cartlist:
        total +=int(unit[3])
    grandtotal=total+100
    return render(request,'cart.html',locals())




def cartorder(request):
    global cartlist,customaddress,customemail,customname,customphone
    allcart=cartlist
    total=0
    for unit in cartlist:
        total +=int(unit[3])
    grandtotal=total+100
    if "myMail" in request.session and "isAlive" in request.session:    
        name=customname
        phone=customphone
        address=customaddress
        email=request.session['myMail']

    
    return render(request,'cartorder.html',locals())




def cartok(request):
    global cartlist,customaddress,customemail,customname,customphone,orderTotal,goodsTitle
    total=0
    for unit in cartlist:
        total +=int(unit[3])
    grandtotal=total+100
    orderTotal=grandtotal
    
    
    customname=request.POST.get('cuName','')
    customphone=request.POST.get('cuPhone','')
    customaddress=request.POST.get('cuAddr','')
    customemail=request.POST.get('cuEmail','')
    payType=request.POST.get('payType','')
    
    sendMail(customemail,cartlist,orderTotal,customname)
    
    unitorder=models.OrdersModel.objects.create(subtotal=total,shipping=100,grandtotal=grandtotal,customname=customname,customemail=customemail,customphone=customphone,customaddress=customaddress,paytype=payType)
    
    for unit in cartlist:
        goodsTitle.append(unit[0]) #將要買的商品新增至goodsTitle中
        total=int(unit[1]) * int(unit[2])
        unitdetail=models.DetailModel.objects.create(dorder=unitorder,pname=unit[0],unitprice=unit[1],quantity=unit[2],dtotal=total)
        
    orderid=unitorder.id #取得訂單編號
    name=unitorder.customname
    email=unitorder.customemail
    cartlist=list()

    request.session['cartlist']=cartlist
    return render(request,'cartok.html',locals())


def cartordercheck(request):
    orderid = request.GET.get('orderid','')
    customemail = request.GET.get('customemail','')
    
    if orderid==''  and customemail=='':
        nosearch=1
    else:
        order=models.OrdersModel.objects.filter(id=orderid,customemail=customemail).first() #抓第一筆資料
        
        if order == None:
            notfound=1
        else:
            details=models.DetailModel.objects.filter(dorder=order)
            
    return render(request,'cartordercheck.html',locals())




def sendMail(email,cartlist,grandtotal,name):
    #建立MIMEMultipart物件
    content = MIMEMultipart()
    
    #郵件標題
    content["subject"] = "購物清單"
    #寄件者
    content["from"] = "jyliu77@gmail.com"
    #收件者
    content["to"] = email
    #郵件內容
    cartdetail=[]
    for i in cartlist:
        cartdetail.append({
             '清單':i[0],
             '數量':i[2],
             '費用':i[3],    
             })

    cartdetail.append({
         '總費用':grandtotal,
         '姓名':name
         })   
        

    content.attach(MIMEText(str(cartdetail)))
    
    #郵件圖片內容
    img_dir = 'static/images/'
    image = 'YOONA.jpg'
    file_path = os.path.join(img_dir, image)
    content.attach(MIMEImage(Path(file_path).read_bytes()))
    with smtplib.SMTP(host="smtp.gmail.com", port="587") as smtp:  # 設定SMTP伺服器
        try:
            smtp.ehlo()  # 驗證SMTP伺服器
            smtp.starttls()  # 建立加密傳輸
            smtp.login("jyliu77@gmail.com", "qijbuqyxhgyknapx")  # 登入寄件者gmail
            smtp.send_message(content)  # 寄送郵件
            print("Complete!")
        except Exception as e:
            print("Error message: ", e)    















