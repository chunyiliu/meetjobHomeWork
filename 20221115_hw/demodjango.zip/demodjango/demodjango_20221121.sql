-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: demodjango
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add cpbl',7,'add_cpbl'),(26,'Can change cpbl',7,'change_cpbl'),(27,'Can delete cpbl',7,'delete_cpbl'),(28,'Can view cpbl',7,'view_cpbl'),(29,'Can add contact',8,'add_contact'),(30,'Can change contact',8,'change_contact'),(31,'Can delete contact',8,'delete_contact'),(32,'Can view contact',8,'view_contact');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$390000$v3GHh6SdRZRvb7IOZ3NvIl$PdqmNf2YLEM8vKJcP/+T+RKNh3gVFLMyjS5wcQigUOw=','2022-11-17 07:10:00.613442',1,'liu','','','jyliu77@gmail.com',1,1,'2022-11-16 02:25:46.164901');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `content` longtext NOT NULL,
  `create_date` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES (1,'liu','jyliu@gmail.com','0987654321','just test','2022-11-17 02:30:23.811208'),(2,'liu','jyliu@gmail.com','0987654321','test2','2022-11-17 07:04:01.338894');
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpbl`
--

DROP TABLE IF EXISTS `cpbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cpbl` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `link` varchar(200) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `postdate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cpbl`
--

LOCK TABLES `cpbl` WRITE;
/*!40000 ALTER TABLE `cpbl` DISABLE KEYS */;
INSERT INTO `cpbl` VALUES (1,'吳哲源7局好投領銜 兄弟連兩年4連勝封王寫新猷','https://www.cpbl.com.tw/xmdoc/cont?sid=0M313861152084706860','https://www.cpbl.com.tw/files/file_pool/1/0m314001844253650032/17097141968602.jpg','2022-11-09'),(2,'鄭凱文7局優質先發奪勝 中信兄弟3勝聽牌','https://www.cpbl.com.tw/xmdoc/cont?sid=0M312825882769630974','https://www.cpbl.com.tw/files/file_pool/1/0m312826372820071589/0cl-inu8.jpeg','2022-11-08'),(3,'泰樂8局好投+陳子豪3分砲 兄弟斬猿連拿兩勝','https://www.cpbl.com.tw/xmdoc/cont?sid=0M310782197187281068','https://www.cpbl.com.tw/files/file_pool/1/0m310782497518170472/069a8243_1.jpg','2022-11-06'),(4,'德保拉7局優質先發 兄弟獲台灣大賽首戰獲勝','https://www.cpbl.com.tw/xmdoc/cont?sid=0M309785717826974119','https://www.cpbl.com.tw/files/file_pool/1/0m309786949804963471/069a6731.jpg','2022-11-05'),(5,'台灣大賽28人名單公布 「象猿大戰」火熱開打','https://www.cpbl.com.tw/xmdoc/cont?sid=0M307583731827909463','https://www.cpbl.com.tw/files/file_pool/1/0m307584131949735584/2022%e5%86%a0%e8%bb%8d%e8%b3%bd_28%e4%ba%ba%e5%90%8d%e5%96%ae-01.png','2022-11-03'),(6,'2022CPBL中華電信台灣大賽 巔峰對決週末點燃戰火','https://www.cpbl.com.tw/xmdoc/cont?sid=0M306597930210301622','https://www.cpbl.com.tw/files/file_pool/1/0m306598163223231627/2022%e5%86%a0%e8%bb%8d%e8%b3%bdlogo_%e5%ae%9aout.png','2022-11-02'),(7,'呂彥青關鍵守勝 兄弟1分差擊敗味全揮軍台灣大賽','https://www.cpbl.com.tw/xmdoc/cont?sid=0M304837085664848435','https://www.cpbl.com.tw/files/file_pool/1/0m304837308232184294/069a8752_1.jpg','2022-10-31'),(8,'鋼龍優質先發搶勝 龍隊延長季後賽戰線','https://www.cpbl.com.tw/xmdoc/cont?sid=0M303839466367507337','https://www.cpbl.com.tw/files/file_pool/1/0m303839941647780216/egg_7183.jpg','2022-10-30'),(9,'德保拉完投壓制龍 中信兄弟搶下第2勝聽牌','https://www.cpbl.com.tw/xmdoc/cont?sid=0M302741376932713250','https://www.cpbl.com.tw/files/file_pool/1/0m302741765007439733/bh1x3lvk.jpeg','2022-10-29'),(10,'38歲換隊再出發 王勝偉獲東山再起獎','https://www.cpbl.com.tw/xmdoc/cont?sid=0M301620343791220345','https://www.cpbl.com.tw/files/file_pool/1/0m301620664626393157/2022%e9%a0%92%e7%8d%8e%e5%85%b8%e7%a6%ae_%e7%a4%be%e7%be%a4_%e6%9d%b1%e5%b1%b1%e5%86%8d%e8%b5%b7%e7%8d%8e.png','2022-10-28'),(11,'季後賽28名單公布 「龍象大戰」29日點燃戰火','https://www.cpbl.com.tw/xmdoc/cont?sid=0M300594486894840072','https://www.cpbl.com.tw/files/file_pool/1/0m300594949982064859/2022%e5%ad%a3%e5%be%8c%e8%b3%bd_28%e4%ba%ba%e5%90%8d%e5%96%ae-01.png','2022-10-27'),(12,'辛元旭敲再見安 富邦悍將主場四連勝本季劃下句號','https://www.cpbl.com.tw/xmdoc/cont?sid=0M299825114895931242','https://www.cpbl.com.tw/files/file_pool/1/0m299832390325204139/yua06223.jpg','2022-10-26'),(13,'呂詠臻先發初登板 龍獅激戰12局言和','https://www.cpbl.com.tw/xmdoc/cont?sid=0M299497149348213823','https://www.cpbl.com.tw/files/file_pool/1/0m299499568331883170/test123.jpeg','2022-10-25'),(14,'辛元旭3打點拿下MVP 富邦6：2擊退樂天','https://www.cpbl.com.tw/xmdoc/cont?sid=0M299033110603941177','https://www.cpbl.com.tw/files/file_pool/1/0m299033858561953446/a2.jpg','2022-10-25'),(15,'壽星伍鐸勝投MVP 助龍隊完封悍將','https://www.cpbl.com.tw/xmdoc/cont?sid=0M298005866049088460','https://www.cpbl.com.tw/files/file_pool/1/0m298006155350832678/s__61653057.jpg','2022-10-24'),(16,'決戰季後賽 龍象大戰爭奪總冠軍賽門票','https://www.cpbl.com.tw/xmdoc/cont?sid=0M297521111546025715','https://www.cpbl.com.tw/files/file_pool/1/0m297567445038319516/s__61620307.jpg','2022-10-24'),(17,'杜家明生涯首轟繳猛打賞 中信奪單季69勝破隊史紀錄','https://www.cpbl.com.tw/xmdoc/cont?sid=0M296834618971863327','https://www.cpbl.com.tw/files/file_pool/1/0m296834930390591737/1023%20brvsrm.jpg','2022-10-23'),(18,'劉俊豪敲安護送超前分 生涯首度獲選MVP','https://www.cpbl.com.tw/xmdoc/cont?sid=0M296813025042953542','https://www.cpbl.com.tw/files/file_pool/1/0m296813699726594579/znsu8oza.jpeg','2022-10-23'),(19,'味全延長賽逼和樂天 送兄弟下半季非自力封王','https://www.cpbl.com.tw/xmdoc/cont?sid=0M296029189284539567','https://www.cpbl.com.tw/files/file_pool/1/0m296029936095683356/a2%20%282%29.jpg','2022-10-22'),(20,'稱霸2022中職二軍 富邦悍將隊史首冠','https://www.cpbl.com.tw/xmdoc/cont?sid=0M295620433629592686','https://www.cpbl.com.tw/files/file_pool/1/0m295710573505740189/930152.jpg','2022-10-22');
/*!40000 ALTER TABLE `cpbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2022-11-17 07:10:41.893182','11','CPBL object (11)',1,'[{\"added\": {}}]',7,1),(2,'2022-11-17 07:11:28.497806','12','CPBL object (12)',1,'[{\"added\": {}}]',7,1),(3,'2022-11-17 07:11:58.357915','13','CPBL object (13)',1,'[{\"added\": {}}]',7,1),(4,'2022-11-17 07:12:25.413745','14','CPBL object (14)',1,'[{\"added\": {}}]',7,1),(5,'2022-11-17 07:13:11.797070','15','CPBL object (15)',1,'[{\"added\": {}}]',7,1),(6,'2022-11-17 07:13:32.729794','16','CPBL object (16)',1,'[{\"added\": {}}]',7,1),(7,'2022-11-17 07:13:55.459251','17','CPBL object (17)',1,'[{\"added\": {}}]',7,1),(8,'2022-11-17 07:14:18.844204','18','CPBL object (18)',1,'[{\"added\": {}}]',7,1),(9,'2022-11-17 07:14:41.777508','19','CPBL object (19)',1,'[{\"added\": {}}]',7,1),(10,'2022-11-17 07:15:02.533798','20','CPBL object (20)',1,'[{\"added\": {}}]',7,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(8,'message','contact'),(7,'news','cpbl'),(6,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2022-11-16 02:25:01.855927'),(2,'auth','0001_initial','2022-11-16 02:25:03.425726'),(3,'admin','0001_initial','2022-11-16 02:25:03.863181'),(4,'admin','0002_logentry_remove_auto_add','2022-11-16 02:25:03.878748'),(5,'admin','0003_logentry_add_action_flag_choices','2022-11-16 02:25:03.894346'),(6,'contenttypes','0002_remove_content_type_name','2022-11-16 02:25:04.129144'),(7,'auth','0002_alter_permission_name_max_length','2022-11-16 02:25:04.269933'),(8,'auth','0003_alter_user_email_max_length','2022-11-16 02:25:04.426236'),(9,'auth','0004_alter_user_username_opts','2022-11-16 02:25:04.441769'),(10,'auth','0005_alter_user_last_login_null','2022-11-16 02:25:04.566814'),(11,'auth','0006_require_contenttypes_0002','2022-11-16 02:25:04.582434'),(12,'auth','0007_alter_validators_add_error_messages','2022-11-16 02:25:04.598009'),(13,'auth','0008_alter_user_username_max_length','2022-11-16 02:25:04.847923'),(14,'auth','0009_alter_user_last_name_max_length','2022-11-16 02:25:05.004137'),(15,'auth','0010_alter_group_name_max_length','2022-11-16 02:25:05.177406'),(16,'auth','0011_update_proxy_permissions','2022-11-16 02:25:05.193063'),(17,'auth','0012_alter_user_first_name_max_length','2022-11-16 02:25:05.333674'),(18,'sessions','0001_initial','2022-11-16 02:25:05.458569'),(19,'news','0001_initial','2022-11-16 05:47:32.675572'),(20,'message','0001_initial','2022-11-17 00:53:44.424517');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-21  9:01:13
