import pymysql

dbsetting={
    "host":"127.0.0.1",
    "port":3306,
    "user":"myuser",
    "password":"lcclcc",
    "db":"demodjango",
    "charset":"utf8"
    }

conn=pymysql.connect(**dbsetting)